# Django Delights Inventory Tracker

## User Login Information

**Username**: `codecademy`

**Password**: `django`

## Get Started

```bash
python manage.py runserver
```

Navigate to [this url](http://localhost:8000/).
